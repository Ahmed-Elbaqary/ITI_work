import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.express as px


#Load Dataset
df = pd.read_csv('airline_data.csv')


app = dash.Dash(__name__, external_stylesheets= ['http://127.0.0.1:8887/style.css'])

app.layout = html.Div(
  className="container",
  children = [
    html.Div(
      className="header",
      children= [
        html.H1('Airline Dashboard')
      ]
    ),
    html.Div(
      className="row",
      children= [
        html.Div(
          className="w-50",
          children= [
            html.Div(
              className="input-box",
              children= [
                dcc.Dropdown(
                className = 'input-form',
                id='state-name',
                options=[{'label': str(i), 'value': str(i)} for i in df.OriginStateName.values],
                placeholder = 'OriginStateName'
                ),
                dcc.Dropdown(
                className = 'input-form',
                id='year',
                options=[{'label': i, 'value': i} for i in df.Year.sort_values().unique()],
                placeholder = 'Year'
                ),
                dcc.Graph(id='pie-chart'),
              ]
            )
          ]
        ),
        html.Div(
          className="w-50",
          children= [
            html.Div(
              className="input-box",
              children= [
                dcc.Dropdown(
                className = 'input-form',
                id='state-name-2',
                options=[{'label': str(i), 'value': str(i)} for i in df.OriginStateName.values],
                placeholder = 'OriginStateName'
                ),
                dcc.Dropdown(
                className = 'input-form',
                id='year-2',
                options=[{'label': i, 'value': i} for i in df.Year.sort_values().unique()],
                placeholder = 'Year'
                ),
                dcc.Graph(id='histogram'),
              ]
            )
          ]
        ),
      ]
    )
  ])
@app.callback(
    dash.dependencies.Output('pie-chart', 'figure'),
    dash.dependencies.Input('state-name', 'value'),
    dash.dependencies.Input('year', 'value'))
def update_pie_chart(state_name, year):
    dff = df.loc[(df['Year'] == year) & (df['OriginStateName'] == state_name)]
    dff = dff.groupby('Quarter').count()

    title = 'The number of flights from '+str(state_name)+' in '+str(year)+' of each quarter'

    fig = px.pie(dff, values='OriginAirportID', names=dff.index, title=title)
    return fig

@app.callback(
    dash.dependencies.Output('histogram', 'figure'),
    dash.dependencies.Input('state-name-2', 'value'),
    dash.dependencies.Input('year-2', 'value'))
def update_histogram(state_name, year):
    dff = df.loc[(df['Year'] == year) & (df['OriginStateName'] == state_name)]
    dff = dff.groupby('Month').mean()

    title_hist = 'The Mean of DepDelayMinutes in '+str(state_name)+' ( '+str(year)+' ) of each Month'

    fig = px.bar(dff, x=dff.index, y='DepDelayMinutes', color='DepDelayMinutes', title=title_hist)
    return fig

if __name__ == '__main__':
    app.run_server(debug=True)
